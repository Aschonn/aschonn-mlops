from setuptools import setup, find_packages

setup (
    name = "src",
    version = "0.0.1",
    description="computer vision version 1 test",
    author="aschonn",
    packages=find_packages(),
    license="MIT",
)