Command Help:

"dvc repro": Checks changes between current and previous models in pipeline.