Command Help:

"dvc repro": Checks changes between current and previous models in pipeline.

tox command:
"tox"

tox rebuild:
"tox -r"

run through tests in pytest:
"pytest -v"

setup command:
"pip install -e ."

create build package, command:
"python setup.py sdist bdist_wheel"


