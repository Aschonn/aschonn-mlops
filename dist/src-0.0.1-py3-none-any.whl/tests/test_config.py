#has to start with test
#Creates a function to test a specific feature

def test_whatever():
    a = 2
    b = 2
    assert a == b